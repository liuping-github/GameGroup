BrowserQuest
============

Documentation is located in client and server directories.